from django.http.response import Http404
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect, HttpResponse
from res1.models import *
from django.shortcuts import render_to_response
#import pdfcrowd
from reportlab.pdfgen import canvas
import cStringIO as StringIO
import ho.pisa as pisa
from django.template.loader import get_template
from django.template import Context
from django.http import HttpResponse
from cgi import escape

def home(request):
    return render(request,'home.html',locals())

def registration(request):
    if request.is_ajax() and request.method == "POST":
	fullname = request.POST.get("fullname")
	email = request.POST.get("emailid")
	#import pdb;pdb.set_trace()
    try:
        Name.objects.get(Full_name=fullname,Email_id=email)
        return render_to_response("error_registration.html",{}, RequestContext(request))
    except:
	nam = Name.objects.create(Full_name=fullname,Email_id=email)
	id = nam.id
	print id
    return render(request,'education.html',{'object_id':nam.id})
    

def addmore(request):
    if request.is_ajax() and request.method == "POST":
	quafn = request.POST.get("quafn")
	univ = request.POST.get("univ")
	year = request.POST.get("year")
	perc = request.POST.get("perc")
	obj_id = request.POST.get('n1')
	print obj_id
	edu = Education.objects.create(Qualification=quafn,University=univ,Year_of_Passing=year,Aggrigation=perc)
	name_obj = Name.objects.get(id=obj_id)
	edu.edn = name_obj
	edu.save()
		
	cmp = request.POST.get("cmp",None) #Certificate Management Protocol#
	if cmp == "true":
	    return render(request,'professional.html',{'object_id':obj_id})
	   
    else:
	raise Http404
    return render(request,'education.html',{'object_id':obj_id})
    
def profn(request):
    
    if request.is_ajax() and request.method == "POST":
	job = request.POST.get("job")
	exp = request.POST.get("exp")
	ind = request.POST.get("ind")
	func = request.POST.get("func")
	key = request.POST.get("key")
	obj_id = request.POST.get('n1')
	print obj_id
	#import pdb;pdb.set_trace()	
	#  Implement save function in mongodb
	pro = Profession.objects.create(Job_Type=job, Total_Experience_in_months=exp,Current_Industry=ind,Functional_Area=func,Key_Skills=key)
        nme = Name.objects.get(id=obj_id)
	pro.prof = nme
	pro.save()
	
	cmp = request.POST.get("cmp",None)
	if cmp == "true":
	    return render(request,'home.html',locals())

    else:
	raise Http404
    return render(request,'professional.html',{'object_id':obj_id})
    #return render(request,'professional.html',locals())
"""
from io import BytesIO
from reportlab.pdfgen import canvas
from django.http import HttpResponse

def some_view(request):
    # Create the HttpResponse object with the appropriate PDF headers.
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="somefilename.pdf"'

    buffer = BytesIO()

    # Create the PDF object, using the BytesIO object as its "file."
    p = canvas.Canvas(buffer)

    # Draw things on the PDF. Here's where the PDF generation happens.
    # See the ReportLab documentation for the full list of functionality.
    p.drawString(100, 100, "Hello world.")

    # Close the PDF object cleanly.
    p.showPage()
    p.save()

    # Get the value of the BytesIO buffer and write it to the response.
    pdf = buffer.getvalue()
    buffer.close()
    response.write(pdf)
    return response

"""



def render_to_pdf(template_src, context_dict):
    template = get_template(template_src)
    context = Context(context_dict)
    html  = template.render(context)
    result = StringIO.StringIO()

    pdf = pisa.pisaDocument(StringIO.StringIO(html.encode("ISO-8859-1")), result)
    if not pdf.err:
        return HttpResponse(result.getvalue(), mimetype='application/pdf')
    return HttpResponse('We had some errors<pre>%s</pre>' % escape(html))

def myview(request):
    #Retrieve data or whatever you need
    return render_to_pdf(
	    #'127.0.0.1:8000/',
            'home.html',
	    #'education.html',
	    #'professional.html',
            {
		'Full_name':'fullname',
		'Email_id':'emailid',
	            }
        )


"""
def generate_pdf_view(my_page):

    #https://docs.djangoproject.com/en/dev/topics/email/

    response = HttpResponse(content_type='application/pdf')
    # uncomment to toggle: downloading | display (moz browser)
    # response['Content-Disposition'] = 'attachment; filename="myfilename.pdf"'

    c = canvas.Canvas(response)
    c.drawString(100, 600, my_page.title)
    c.showPage
    c.save()
    return response
"""
"""
import sys
#from PyQt4 import QtCore, QtGui, QtWebKit

class WebPage(QtWebKit.QWebPage):
    def __init__(self):
        QtWebKit.QWebPage.__init__(self)
        self.printer = QtGui.QPrinter()
        self.printer.setPageSize(QtGui.QPrinter.Letter)
        self.printer.setOrientation(QtGui.QPrinter.Landscape);
        self.printer.setOutputFormat(QtGui.QPrinter.PdfFormat)
        self.mainFrame().loadFinished.connect(self.handleLoadFinished)

    def start(self, url):
        self.mainFrame().load(QtCore.QUrl(url))
        QtGui.qApp.exec_()

    def handleLoadFinished(self):
        temp = QtCore.QTemporaryFile(
            QtCore.QDir.temp().filePath('webpage.XXXXXX.pdf'))
        # must open the file to get the filename.
        # file will be automatically deleted later
        temp.open()
        self.printer.setOutputFileName(temp.fileName())
        # ensure that the file can be written to
        temp.close()
        self.mainFrame().print_(self.printer)
        temp.open()
        self.pdf = temp.readAll().data()
        QtGui.qApp.quit()

def webpage2pdf(url):
    if not hasattr(WebPage, 'app'):
        # can only have one QApplication, and it must be created first
        WebPage.app = QtGui.QApplication(sys.argv)
    webpage = WebPage()
    webpage.start(url)
    return webpage.pdf

if __name__ == '__main__':

    if len(sys.argv) > 1:
        url = sys.argv[1]
    else:
        url = 'http://www.google.com'

    result = webpage2pdf(url)

    response =  HttpResponse(result, mimetype='application/pdf')
    response['Content-Disposition'] = 'attachment; filename=coupon.pdf'
    # do stuff with response...

"""
"""
def generate_pdf_view(request):
    try:
        # create an API client instance
        client = pdfcrowd.Client("Lakshmisree", "40c397da666bd3340081b1274fb51fb0")

        # convert a web page and store the generated PDF to a variable
        pdf = client.convertURI("http://demo-resumeapp-creyo.herokuapp.com/")

         # set HTTP response headers
        response = HttpResponse(mimetype="application/pdf")
        response["Cache-Control"] = "no-cache"
        response["Accept-Ranges"] = "none"
        response["Content-Disposition"] = "attachment; filename=Resume_application.pdf"

        # send the generated PDF
        response.write(pdf)
    except pdfcrowd.Error, why:
        response = HttpResponse(mimetype="text/plain")
        response.write(why)
    return response
"""

"""
import cStringIO as StringIO

import ho.pisa as pisa
import requests

def pdf_maker(request):

    browser = requests.get('http://www.google.com/')
    html = browser.text

    result = StringIO.StringIO()
    source = StringIO.StringIO(html.encode('UTF-8')) # adjust as required

    pdf = pisa.pisaDocument(source,dest=result)

    if not pdf.err:
        response = HttpResponse(result.getvalue(),mimetype='application/pdf')
        response['Content-Disposition'] = 'attachment; filename=the_file.pdf'
        return response

    return render(request,'error.html')
"""


"""

There are several options out there:

    reportlab (suggested by django docs)
    PDFMiner (or +slate wrapper)
    pdfrw
    xhtml2pdf
    pyfpdf (no changes since august, 2012)
    pyPdf (not maintained)

Also take a look at:

    Python PDF library
    Outputting PDFs with Django
    Open Source PDF Libraries in Python
    Generating PDFs with Django
    Django, ReportLab PDF Generation attached to an email
    A Simple Step-by-Step Reportlab Tutorial
    Django output pdf using reportlab

Hope that helps.
"""

"""
def some_view(request):
    # Create the HttpResponse object with the appropriate PDF headers.
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="somefilename.pdf"'

    # Create the PDF object, using the response object as its "file."
    p = canvas.Canvas(response)

    # Draw things on the PDF. Here's where the PDF generation happens.
    # See the ReportLab documentation for the full list of functionality.
    p.drawString(100, 100, "Hello world.")

    # Close the PDF object cleanly, and we're done.
    p.showPage()
    p.save()
    return response
"""


