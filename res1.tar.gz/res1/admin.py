from django.contrib import admin
from res1.models import *
from django.contrib.sites.models import Site

#admin.site.unregister(Site)
admin.site.register(Education)
admin.site.register(Profession)
admin.site.register(Name)	


